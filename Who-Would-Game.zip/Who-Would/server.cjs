const http=require('node:http'),fs=require('node:fs'),crypto=require('node:crypto');
const questions=require('./questions.cjs');
const rooms=new Map();
const token=()=>crypto.randomBytes(24).toString('hex');
const fail=(message)=>{throw Error(message)};
function settings(b){if(!['friends','couples','family'].includes(b.category)||![5,10,15,20].includes(b.count))fail('SETTINGS');return {category:b.category,count:b.count};}
function player(b){const name=String(b.name||'').trim().slice(0,24);if(!name)fail('NAME');return {id:crypto.randomUUID(),token:token(),name,avatar:Math.max(0,Math.min(11,Number(b.avatar)||0))};}
function publicState(r,p){return {code:r.code,phase:r.phase,players:r.players.map(({id,name,avatar})=>({id,name,avatar})),host:p.id===r.host,me:p.id,category:r.category,count:r.count,round:r.round,question:r.deck?.[r.round],voted:!!r.votes[p.id],voters:Object.keys(r.votes),tally:r.phase==='result'?r.tally:null,history:r.history,revision:r.revision};}
function reveal(r){r.tally=Object.fromEntries(r.players.map(p=>[p.id,0]));Object.values(r.votes).forEach(id=>r.tally[id]++);r.history.push({question:r.deck[r.round],tally:{...r.tally}});r.phase='result';}
function act(b){
 if(b.action==='create'){if(rooms.size>=500)fail('BUSY');const p=player(b),s=settings(b);let code;do{code=crypto.randomBytes(4).toString('hex').slice(0,6).toUpperCase()}while(rooms.has(code));const r={code,...s,players:[p],host:p.id,phase:'lobby',round:0,votes:{},history:[],revision:1,updated:Date.now()};rooms.set(code,r);return {token:p.token,state:publicState(r,p)};}
 const r=rooms.get(String(b.code||'').toUpperCase());if(!r)fail('ROOM');r.updated=Date.now();
 if(b.action==='join'){if(r.phase!=='lobby')fail('STARTED');if(r.players.length>=8)fail('FULL');const p=player(b);if(r.players.some(x=>x.name.toLowerCase()===p.name.toLowerCase()))fail('DUPLICATE_NAME');r.players.push(p);r.revision++;return {token:p.token,state:publicState(r,p)};}
 const p=r.players.find(p=>p.token===b.token);if(!p)fail('SESSION');
 if(b.action==='state')return {state:publicState(r,p)};
 if(b.action==='vote'){if(r.phase!=='vote'||b.round!==r.round)fail('ROUND');if(r.votes[p.id])fail('VOTED');if(!r.players.some(p=>p.id===b.target))fail('TARGET');r.votes[p.id]=b.target;if(Object.keys(r.votes).length===r.players.length)reveal(r);}
 else {if(p.id!==r.host)fail('HOST');
  if(b.action==='start'){if(r.phase!=='lobby')fail('PHASE');if(r.players.length<3)fail('MIN');r.deck=questions.filter(q=>q.category===r.category).map(q=>({q,k:crypto.randomBytes(8).toString('hex')})).sort((a,b)=>a.k.localeCompare(b.k)).slice(0,r.count).map(x=>x.q);r.phase='vote';}
  else if(b.action==='next'){if(r.phase!=='result')fail('PHASE');r.round++;r.votes={};r.phase=r.round>=r.count?'end':'vote';}
  else if(b.action==='restart'){if(r.phase!=='end')fail('PHASE');r.phase='lobby';r.round=0;r.history=[];r.votes={};}
  else if(b.action==='remove'){if(b.target===r.host||!r.players.some(x=>x.id===b.target))fail('TARGET');if(!['lobby','vote'].includes(r.phase)||r.phase==='vote'&&r.players.length<=3)fail('MIN');if(r.phase==='vote'&&Object.values(r.votes).includes(b.target))fail('HAS_VOTES');r.players=r.players.filter(x=>x.id!==b.target);delete r.votes[b.target];if(r.phase==='vote'&&Object.keys(r.votes).length===r.players.length)reveal(r);}
  else fail('ACTION');
 }
 r.revision++;return {state:publicState(r,p)};
}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');
 if(req.url==='/api/health'){res.writeHead(200,{'Content-Type':'application/json'});return res.end('{"ok":true}');}
 if(req.url==='/api'&&req.method==='POST'){
  if(req.headers.origin&&req.headers.origin!==`${req.headers['x-forwarded-proto']||'http'}://${req.headers.host}`){res.writeHead(403);return res.end();}
  try {let body='';for await(const chunk of req){body+=chunk;if(body.length>4096)fail('SIZE');}const result=act(JSON.parse(body));res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(result));}catch(e){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}return;
 }
 if(req.method==='GET'&&['/','/index.html'].includes(req.url.split('?')[0])){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(__dirname+'/index.html'));}
 res.writeHead(404);res.end('Not found');
});
setInterval(()=>{for(const [code,r]of rooms)if(Date.now()-r.updated>2*60*60*1000)rooms.delete(code);},60000).unref();
server.listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('Who Would ready on port '+(process.env.PORT||3000)));
