BUNU KIM YAPAR? / WHO WOULD?

TEK TELEFONDA
index.html dosyasını bir tarayıcıda açın. İnternet veya hesap gerekmez.
3–8 farklı oyuncu adı girin, kategori ve 5/10/15/20 soru seçin.
Telefonu sırayla paylaşın. Oylar soru bitene kadar gizlidir.

AYRI TELEFONLARDA
Bu ZIP sunucu dahil oyunun kaynak dosyalarını içerir.
Node.js 22 veya üzeri kurulu bilgisayarda bu klasörde:
  npm start
Bilgisayarda http://localhost:3000 adresini açın.
Aynı Wi-Fi üzerindeki telefonlarda bilgisayarın yerel IP adresini kullanın:
  http://BILGISAYARIN-IP-ADRESI:3000
Güvenlik duvarının yerel ağ bağlantısına izin vermesi gerekebilir.
Bir oyuncu oda kurar. Diğerleri aynı oyun adresinden kodla katılır.
En az 3 oyuncudan sonra oda sahibi başlatır. En fazla 8 oyuncu.
Her soru herkes oy verince açılır; sonraki soruya oda sahibi geçer.
Oyuncular aynı sekmede bağlantı geri geldiğinde oturumlarına döner.
Yeni tur aynı oda içinde başlatılabilir.

INTERNETTEN YAYINLAMA
Sunucu sürekli çalışan bir Node.js hizmetine yüklenmeli.
Çalıştırma: npm start. PORT ortam değişkeni desteklenir.
HTTPS üzerinden tek alan adı kullanın; ters proxy aynı alan adını
ve X-Forwarded-Proto başlığını iletmelidir.
GitHub Pages yalnızca tek telefon modunu çalıştırır; oda sunucusunu çalıştırmaz.
Bu paket hazırlanmış ve yerel olarak test edilmiştir; internete yayınlanmamıştır.

SINIRLAR
Odalar sunucunun belleğinde tutulur; sunucu yeniden başlarsa silinir.
Tek sunucu örneği kullanın; birden fazla örnek ortak oda verisi gerektirir.
2 saat boyunca hiç işlem/poll gelmeyen odalar silinir.
Oda sahibi bağlantısı kesilirse aynı sekmeyle geri dönmesi gerekir.
Oy vermeyen oyuncu ancak en az 3 kişi kalacaksa ve hiç oy almamışsa
oda sahibi tarafından soru ortasında çıkarılabilir. Oy alınan oyuncunun
bağlantısı dönene kadar beklenir. Oda sahibini değiştirme yoktur.
Tarayıcıya bağlı olarak paylaşım menüsü yerine kart indirme açılır.
Bu ilk sürümde hesaplar, reklamlar ve ödemeler yoktur.

SORULAR
60 özgün soru: her kategoride 20. Her soru Türkçe ve İngilizce.
Sorular tur içinde tekrar etmez; yeni turlarda rastgele seçilir.
Çiftler kategorisi de istenen 3–8 kişi sınırını kullanır.
Soruları değiştirmek için questions.cjs ve index.html içindeki
QUESTIONS listesini birlikte güncelleyin.

TEST
  npm test
Sunucu oyun akışı, beraberlik, oy gizliliği ve oda sınırları test edildi.
Bu ortamda tarayıcı kurulamadığı için görsel tarayıcı testi yapılamadı.
