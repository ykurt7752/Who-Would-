const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const questions=require('./questions.cjs');
const child=spawn(process.execPath,['server.cjs'],{cwd:__dirname,env:{...process.env,PORT:'3199'},stdio:['ignore','pipe','inherit']});
const ready=new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',code=>reject(Error('Server exited '+code)))});
after(()=>child.kill());
async function request(body){await ready;const r=await fetch('http://127.0.0.1:3199/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:r.status,...await r.json()}}
async function room(count=5,category='friends'){const host=await request({action:'create',name:'Matt',avatar:0,count,category});const code=host.state.code;const b=await request({action:'join',code,name:'Alex',avatar:1});const c=await request({action:'join',code,name:'Sam',avatar:2});return [host,b,c].map(p=>({code,token:p.token,id:p.state.me}))}
test('every category supports 20 bilingual, unique questions',()=>{for(const category of ['friends','couples','family']){const q=questions.filter(x=>x.category===category);assert.equal(q.length,20);assert.equal(new Set(q.map(x=>x.id)).size,20);for(const row of q)for(const k of ['tr','en','title_tr','title_en'])assert.ok(row[k])}});
test('full game hides ballots, reveals ties, rejects duplicates and stale votes, then restarts',async()=>{
 const ps=await room();const host=ps[0];let d=await request({action:'start',...host});assert.equal(d.state.phase,'vote');assert.ok(d.state.players.every(p=>!('token' in p)));assert.notEqual(host.token,host.id);
 const seen=new Set();for(let round=0;round<5;round++){
  seen.add(d.state.question.id);
  const v=await request({action:'vote',...ps[0],round,target:ps[0].id});assert.equal(v.state.tally,null);assert.equal(v.state.history.length,round);
  assert.equal((await request({action:'vote',...ps[0],round,target:ps[1].id})).error,'VOTED');
  assert.equal((await request({action:'next',...ps[1]})).error,'HOST');
  await request({action:'vote',...ps[1],round,target:ps[1].id});d=await request({action:'vote',...ps[2],round,target:ps[2].id});
  assert.equal(d.state.phase,'result');assert.deepEqual(Object.values(d.state.tally),[1,1,1]);
  assert.equal((await request({action:'vote',...ps[1],round,target:ps[1].id})).error,'ROUND');
  d=await request({action:'next',...host});
 }
 assert.equal(seen.size,5);assert.equal(d.state.phase,'end');assert.equal(d.state.history.length,5);
 d=await request({action:'restart',...host});assert.equal(d.state.phase,'lobby');assert.equal(d.state.history.length,0);
});
test('3–8 players, join limits, session authentication and round options',async()=>{
 const a=await request({action:'create',name:'A',category:'family',count:20});const p={code:a.state.code,token:a.token};
 assert.equal((await request({action:'start',...p})).error,'MIN');
 assert.equal((await request({action:'join',code:p.code,name:'A'})).error,'DUPLICATE_NAME');
 for(let i=1;i<8;i++)assert.equal((await request({action:'join',code:p.code,name:'P'+i})).status,200);
 assert.equal((await request({action:'join',code:p.code,name:'Extra'})).error,'FULL');
 assert.equal((await request({action:'state',code:p.code,token:'wrong'})).error,'SESSION');
 assert.equal((await request({action:'create',name:'X',category:'family',count:7})).error,'SETTINGS');
 for(const count of [5,10,15,20]){const ps=await room(count,'couples');const d=await request({action:'start',...ps[0]});assert.equal(d.state.count,count);assert.equal(d.state.question.category,'couples');assert.equal((await request({action:'join',code:ps[0].code,name:'Late'})).error,'STARTED')}
});
